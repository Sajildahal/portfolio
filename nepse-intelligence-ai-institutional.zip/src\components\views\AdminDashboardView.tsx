"use client";

import React, { useState } from "react";
import {
  ShieldCheck,
  Users,
  Server,
  Activity,
  DollarSign,
  Bot,
  FileText,
  Clock,
  CheckCircle2,
  AlertCircle,
  Database,
  Lock,
  Sliders,
  Sparkles,
  RefreshCw,
  Cpu,
  Layers,
  Radio,
  Wifi,
  Scale,
  Key,
} from "lucide-react";
import {
  INITIAL_ADMIN_USERS,
  INITIAL_AUDIT_LOGS,
  INITIAL_DATA_PROVIDERS,
  AdminUser,
  AuditLog,
  DataProviderStatus,
} from "@/lib/admin/adminStore";
import { DEFAULT_FEE_SCHEDULE } from "@/lib/financial/nepseFeeEngine";

export function AdminDashboardView() {
  const [activeAdminTab, setActiveAdminTab] = useState<
    "ai-master" | "telemetry" | "users" | "data-providers" | "fees" | "audit"
  >("ai-master");

  const [users, setUsers] = useState<AdminUser[]>(INITIAL_ADMIN_USERS);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>(INITIAL_AUDIT_LOGS);
  const [dataProviders] = useState<DataProviderStatus[]>(INITIAL_DATA_PROVIDERS);

  // AI Model Weights interactive state
  const [weights, setWeights] = useState({
    technical: 30,
    fundamental: 25,
    marketRegime: 15,
    liquidity: 10,
    sentiment: 10,
    riskAdjusted: 10,
  });

  const [isRetraining, setIsRetraining] = useState(false);
  const [retrainSuccess, setRetrainSuccess] = useState(false);

  // Regulatory Fee Schedule interactive state
  const [feeSchedule, setFeeSchedule] = useState({
    sebonFeeRate: 0.00015,
    dpFee: 25.0,
    cgtShortTermRate: 0.075,
    cgtLongTermRate: 0.05,
    cgtCorporateRate: 0.1,
  });
  const [feeSaved, setFeeSaved] = useState(false);

  const totalWeight = Object.values(weights).reduce((a, b) => a + b, 0);

  const handleRetrainModel = () => {
    setIsRetraining(true);
    setRetrainSuccess(false);
    setTimeout(() => {
      setIsRetraining(false);
      setRetrainSuccess(true);
      // Append to audit log
      const newAudit: AuditLog = {
        id: "log-" + Date.now(),
        timestamp: new Date().toISOString(),
        adminEmail: "superadmin@nepseintelligence.ai",
        action: `Recalibrated Ensemble Weights: Tech ${weights.technical}%, Fund ${weights.fundamental}%, Mkt ${weights.marketRegime}%`,
        category: "AI_MODEL",
        previousValue: "Model v3.4.1",
        newValue: "Model v3.4.2",
      };
      setAuditLogs((prev) => [newAudit, ...prev]);
      setTimeout(() => setRetrainSuccess(false), 4000);
    }, 1800);
  };

  const handleSaveFees = () => {
    setFeeSaved(true);
    const newAudit: AuditLog = {
      id: "log-" + Date.now(),
      timestamp: new Date().toISOString(),
      adminEmail: "superadmin@nepseintelligence.ai",
      action: "Updated SEBON regulatory fee schedule",
      category: "FEE_SCHEDULE",
      previousValue: "SEBON 0.015%, DP 25",
      newValue: `SEBON ${(feeSchedule.sebonFeeRate * 100).toFixed(3)}%, DP ${feeSchedule.dpFee}`,
    };
    setAuditLogs((prev) => [newAudit, ...prev]);
    setTimeout(() => setFeeSaved(false), 3000);
  };

  return (
    <div className="space-y-6">
      {/* Admin Master Header */}
      <div className="rounded-2xl border border-bronze bg-charcoal p-6 shadow-gold">
        <div className="flex items-center space-x-2">
          <span className="flex items-center space-x-1.5 rounded-full bg-gold/15 px-3 py-1 text-xs font-bold text-gold border border-gold/30">
            <ShieldCheck className="h-3.5 w-3.5 text-gold" />
            <span>ENTERPRISE BACK-OFFICE MASTER CONTROL</span>
          </span>
          <span className="rounded-full bg-slate-800/80 px-2.5 py-0.5 text-[10px] font-mono text-champagne border border-bronze">
            SUPER ADMINISTRATOR &amp; QUANT CHIEF
          </span>
        </div>
        <h1 className="mt-2 text-2xl font-black text-white sm:text-3xl">
          AI Intelligence Master Control Console
        </h1>
        <p className="mt-1 text-xs text-slate-400 max-w-2xl">
          Ensemble quantitative model retraining, live factor weighting, NEPSE &amp; SEBON market data gateways, user RBAC privileges, and cryptographically verified audit records.
        </p>
      </div>

      {/* Admin Navigation Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-bronze/60 pb-2 text-xs font-semibold">
        {[
          { key: "ai-master", label: "AI Model & Quant Calibration", icon: Bot, badge: "Core" },
          { key: "telemetry", label: "System Telemetry & Ingestion", icon: Server },
          { key: "fees", label: "SEBON Fee Schedule Master", icon: DollarSign },
          { key: "users", label: "User Management (RBAC)", icon: Users },
          { key: "data-providers", label: "Market Data Gateways", icon: Database },
          { key: "audit", label: "Immutable Audit Ledger", icon: FileText },
        ].map((tab) => {
          const Icon = tab.icon;
          const isActive = activeAdminTab === tab.key;
          return (
            <button
              key={tab.key}
              onClick={() => setActiveAdminTab(tab.key as any)}
              className={`flex items-center space-x-2 rounded-xl px-4 py-2 transition-all ${
                isActive
                  ? "gold-gradient-btn text-black font-black shadow-gold"
                  : "border border-bronze bg-obsidian text-slate-400 hover:text-champagne hover:border-gold/30"
              }`}
            >
              <Icon className="h-4 w-4" />
              <span>{tab.label}</span>
              {tab.badge && (
                <span className="rounded bg-black/20 px-1.5 py-0.2 text-[9px] font-bold">
                  {tab.badge}
                </span>
              )}
            </button>
          );
        })}
      </div>

      {/* Tab 1: AI Model & Quant Calibration */}
      {activeAdminTab === "ai-master" && (
        <div className="space-y-6">
          {/* Top Model Health Stats */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 font-mono text-xs">
            <div className="rounded-xl border border-bronze bg-charcoal p-4 space-y-1">
              <span className="text-slate-400 font-sans text-[11px] block">Model Win Rate (Walk-Forward)</span>
              <span className="text-2xl font-bold text-emerald-400 block">76.4%</span>
              <span className="text-[10px] text-slate-500 font-sans">Tested on 5-year NEPSE OHLCV</span>
            </div>

            <div className="rounded-xl border border-bronze bg-charcoal p-4 space-y-1">
              <span className="text-slate-400 font-sans text-[11px] block">Brier Calibration Error</span>
              <span className="text-2xl font-bold text-champagne block">0.142</span>
              <span className="text-[10px] text-slate-500 font-sans">High probability fidelity</span>
            </div>

            <div className="rounded-xl border border-bronze bg-charcoal p-4 space-y-1">
              <span className="text-slate-400 font-sans text-[11px] block">Ensemble Sharpe Ratio</span>
              <span className="text-2xl font-bold text-gold block">2.18</span>
              <span className="text-[10px] text-slate-500 font-sans">Risk-adjusted benchmark</span>
            </div>

            <div className="rounded-xl border border-bronze bg-charcoal p-4 space-y-1">
              <span className="text-slate-400 font-sans text-[11px] block">Signal Universe Coverage</span>
              <span className="text-2xl font-bold text-sky-400 block">282 Equities</span>
              <span className="text-[10px] text-slate-500 font-sans">100% NEPSE Listed Stocks</span>
            </div>
          </div>

          {/* Factor Weights Calibration & Action Distribution */}
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
            {/* Factor Weights Tuning (7 Cols) */}
            <div className="lg:col-span-7 rounded-2xl border border-bronze bg-charcoal p-6 space-y-5">
              <div className="flex items-center justify-between border-b border-bronze pb-3">
                <div>
                  <h2 className="text-sm font-bold text-champagne flex items-center space-x-2">
                    <Sliders className="h-4 w-4 text-gold" />
                    <span>Multi-Factor Model Weights Calibration</span>
                  </h2>
                  <p className="text-[11px] text-slate-400">
                    Adjust factor contributions to the 100-point Stock Intelligence Score.
                  </p>
                </div>
                <span
                  className={`text-xs font-mono font-bold px-2 py-0.5 rounded border ${
                    totalWeight === 100
                      ? "text-emerald-400 bg-emerald-500/15 border-emerald-500/30"
                      : "text-rose-400 bg-rose-500/15 border-rose-500/30"
                  }`}
                >
                  Sum: {totalWeight}% {totalWeight === 100 ? "(Balanced)" : "(Must equal 100%)"}
                </span>
              </div>

              <div className="space-y-4 text-xs">
                {/* Technical Strength */}
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-semibold text-slate-300">Technical Strength (Price, Trend, Momentum)</span>
                    <span className="font-mono font-bold text-sky-400">{weights.technical}%</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="50"
                    value={weights.technical}
                    onChange={(e) => setWeights({ ...weights, technical: Number(e.target.value) })}
                    className="w-full accent-[#38BDF8] cursor-pointer"
                  />
                </div>

                {/* Fundamental Quality */}
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-semibold text-slate-300">Fundamental Quality (ROE, EPS, Book Value)</span>
                    <span className="font-mono font-bold text-emerald-400">{weights.fundamental}%</span>
                  </div>
                  <input
                    type="range"
                    min="10"
                    max="50"
                    value={weights.fundamental}
                    onChange={(e) => setWeights({ ...weights, fundamental: Number(e.target.value) })}
                    className="w-full accent-[#10B981] cursor-pointer"
                  />
                </div>

                {/* Market & Sector Strength */}
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-semibold text-slate-300">Market &amp; Sector Regime</span>
                    <span className="font-mono font-bold text-gold">{weights.marketRegime}%</span>
                  </div>
                  <input
                    type="range"
                    min="5"
                    max="30"
                    value={weights.marketRegime}
                    onChange={(e) => setWeights({ ...weights, marketRegime: Number(e.target.value) })}
                    className="w-full accent-[#D4AF37] cursor-pointer"
                  />
                </div>

                {/* Liquidity & Tradability */}
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-semibold text-slate-300">Liquidity &amp; Tradability (Turnover, Volume)</span>
                    <span className="font-mono font-bold text-purple-400">{weights.liquidity}%</span>
                  </div>
                  <input
                    type="range"
                    min="5"
                    max="25"
                    value={weights.liquidity}
                    onChange={(e) => setWeights({ ...weights, liquidity: Number(e.target.value) })}
                    className="w-full accent-[#A855F7] cursor-pointer"
                  />
                </div>

                {/* Sentiment & Events */}
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-semibold text-slate-300">News &amp; Disclosure Sentiment</span>
                    <span className="font-mono font-bold text-amber-400">{weights.sentiment}%</span>
                  </div>
                  <input
                    type="range"
                    min="5"
                    max="25"
                    value={weights.sentiment}
                    onChange={(e) => setWeights({ ...weights, sentiment: Number(e.target.value) })}
                    className="w-full accent-[#F59E0B] cursor-pointer"
                  />
                </div>

                {/* Risk-Adjusted Opportunity */}
                <div>
                  <div className="flex justify-between items-center mb-1">
                    <span className="font-semibold text-slate-300">Risk-Adjusted Reward/Risk Ratio</span>
                    <span className="font-mono font-bold text-champagne">{weights.riskAdjusted}%</span>
                  </div>
                  <input
                    type="range"
                    min="5"
                    max="25"
                    value={weights.riskAdjusted}
                    onChange={(e) => setWeights({ ...weights, riskAdjusted: Number(e.target.value) })}
                    className="w-full accent-[#F5E6A8] cursor-pointer"
                  />
                </div>
              </div>

              {/* Retrain Action Button */}
              <div className="pt-3 border-t border-bronze flex items-center justify-between">
                <span className="text-[11px] text-slate-400">
                  Target: NEPSE-QUANT-ENSEMBLE v3.4.2
                </span>
                <button
                  onClick={handleRetrainModel}
                  disabled={isRetraining || totalWeight !== 100}
                  className="gold-gradient-btn rounded-xl px-5 py-2.5 text-xs font-black shadow-gold flex items-center space-x-2 disabled:opacity-50"
                >
                  <RefreshCw className={`h-4 w-4 ${isRetraining ? "animate-spin" : ""}`} />
                  <span>{isRetraining ? "Calibrating Walk-Forward..." : "Deploy Weights & Retrain"}</span>
                </button>
              </div>

              {retrainSuccess && (
                <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-3 text-xs text-emerald-300 flex items-center space-x-2">
                  <CheckCircle2 className="h-4 w-4 text-emerald-400" />
                  <span>Model weights deployed successfully across all 282 listed NEPSE tickers!</span>
                </div>
              )}
            </div>

            {/* Current Signal Distribution & Thresholds (5 Cols) */}
            <div className="lg:col-span-5 rounded-2xl border border-bronze bg-charcoal p-6 space-y-5">
              <div className="border-b border-bronze pb-3">
                <h2 className="text-sm font-bold text-champagne flex items-center space-x-2">
                  <Cpu className="h-4 w-4 text-gold" />
                  <span>Universe Signal Distribution</span>
                </h2>
                <p className="text-[11px] text-slate-400">
                  Current active actions across all 282 listed companies.
                </p>
              </div>

              <div className="space-y-3 font-mono text-xs">
                {/* BUY */}
                <div className="flex items-center justify-between border border-emerald-500/30 bg-emerald-950/20 rounded-xl p-3">
                  <div>
                    <span className="text-emerald-400 font-bold block text-sm">BUY (Stage B)</span>
                    <span className="text-[10px] text-slate-400 font-sans">Score &ge; 75 &amp; R:R &ge; 1.8</span>
                  </div>
                  <span className="text-xl font-bold text-white">24 Stocks (8.5%)</span>
                </div>

                {/* HOLD */}
                <div className="flex items-center justify-between border border-amber-500/30 bg-amber-950/20 rounded-xl p-3">
                  <div>
                    <span className="text-amber-400 font-bold block text-sm">HOLD (Neutral/Constructive)</span>
                    <span className="text-[10px] text-slate-400 font-sans">Score 50–74</span>
                  </div>
                  <span className="text-xl font-bold text-white">142 Stocks (50.4%)</span>
                </div>

                {/* REDUCE */}
                <div className="flex items-center justify-between border border-orange-500/30 bg-orange-950/20 rounded-xl p-3">
                  <div>
                    <span className="text-orange-400 font-bold block text-sm">REDUCE (Partial Profit)</span>
                    <span className="text-[10px] text-slate-400 font-sans">Score &le; 45 (Holding owned)</span>
                  </div>
                  <span className="text-xl font-bold text-white">46 Stocks (16.3%)</span>
                </div>

                {/* SELL */}
                <div className="flex items-center justify-between border border-rose-500/30 bg-rose-950/20 rounded-xl p-3">
                  <div>
                    <span className="text-rose-400 font-bold block text-sm">SELL (Breakdown/Urgent)</span>
                    <span className="text-[10px] text-slate-400 font-sans">Risk &ge; 80 or severe breach</span>
                  </div>
                  <span className="text-xl font-bold text-white">32 Stocks (11.3%)</span>
                </div>

                {/* AVOID */}
                <div className="flex items-center justify-between border border-slate-700 bg-slate-900 rounded-xl p-3">
                  <div>
                    <span className="text-slate-400 font-bold block text-sm">AVOID (High Downside Risk)</span>
                    <span className="text-[10px] text-slate-500 font-sans">No position, weak thesis</span>
                  </div>
                  <span className="text-xl font-bold text-white">38 Stocks (13.5%)</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 2: System Telemetry */}
      {activeAdminTab === "telemetry" && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4 font-mono text-xs">
            <div className="rounded-xl border border-bronze bg-charcoal p-4">
              <span className="text-slate-400 font-sans text-[11px] block">Server Uptime</span>
              <span className="text-xl font-bold text-emerald-400 mt-1 block">99.98%</span>
              <span className="text-slate-500 text-[10px] font-sans">0 downtime incidents</span>
            </div>

            <div className="rounded-xl border border-bronze bg-charcoal p-4">
              <span className="text-slate-400 font-sans text-[11px] block">Active WebSocket Sessions</span>
              <span className="text-xl font-bold text-gold mt-1 block">342 Traders</span>
              <span className="text-slate-500 text-[10px] font-sans">Live L2 stream subscribers</span>
            </div>

            <div className="rounded-xl border border-bronze bg-charcoal p-4">
              <span className="text-slate-400 font-sans text-[11px] block">Database Response Latency</span>
              <span className="text-xl font-bold text-white mt-1 block">2.4 ms</span>
              <span className="text-slate-500 text-[10px] font-sans">TimescaleDB index hit 99.4%</span>
            </div>

            <div className="rounded-xl border border-bronze bg-charcoal p-4">
              <span className="text-slate-400 font-sans text-[11px] block">AI Inference Latency</span>
              <span className="text-xl font-bold text-champagne mt-1 block">145 ms</span>
              <span className="text-slate-500 text-[10px] font-sans">Quant-Ensemble v3.4</span>
            </div>
          </div>

          {/* Ingestion Pipelines */}
          <div className="rounded-2xl border border-bronze bg-charcoal p-5 space-y-3">
            <h3 className="text-xs font-bold uppercase tracking-wider text-champagne">
              Ingestion Pipelines &amp; Health Checks
            </h3>
            <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 font-mono text-xs">
              <div className="border border-bronze bg-obsidian rounded-xl p-3 space-y-1">
                <div className="flex items-center space-x-2">
                  <span className="h-2 w-2 rounded-full bg-emerald-500 animate-ping"></span>
                  <span className="font-bold text-white">NEPSE Primary L2 Stream</span>
                </div>
                <div className="text-[11px] text-slate-400">Latency: 12ms · Packet Loss: 0.00%</div>
              </div>
              <div className="border border-bronze bg-obsidian rounded-xl p-3 space-y-1">
                <div className="flex items-center space-x-2">
                  <span className="h-2 w-2 rounded-full bg-emerald-500"></span>
                  <span className="font-bold text-white">SEBON Disclosures Feed</span>
                </div>
                <div className="text-[11px] text-slate-400">Status: Healthy · Poll Interval: 60s</div>
              </div>
              <div className="border border-bronze bg-obsidian rounded-xl p-3 space-y-1">
                <div className="flex items-center space-x-2">
                  <span className="h-2 w-2 rounded-full bg-emerald-500"></span>
                  <span className="font-bold text-white">Redis Cache &amp; Pub/Sub</span>
                </div>
                <div className="text-[11px] text-slate-400">Hit Rate: 98.6% · Memory: 214 MB</div>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 3: Regulatory Fees Master */}
      {activeAdminTab === "fees" && (
        <div className="rounded-2xl border border-bronze bg-charcoal p-6 space-y-6">
          <div className="flex items-center justify-between border-b border-bronze pb-3">
            <div>
              <h2 className="text-sm font-bold text-champagne flex items-center space-x-2">
                <Scale className="h-4 w-4 text-gold" />
                <span>SEBON Regulatory Fee Schedules &amp; Broker Commission Slabs</span>
              </h2>
              <p className="text-[11px] text-slate-400">
                Official Nepal capital market fee parameters enforced across the entire platform.
              </p>
            </div>
            <button
              onClick={handleSaveFees}
              className="gold-gradient-btn rounded-xl px-4 py-2 text-xs font-black shadow-gold flex items-center space-x-1.5"
            >
              <CheckCircle2 className="h-4 w-4" />
              <span>Save &amp; Propagate</span>
            </button>
          </div>

          {feeSaved && (
            <div className="rounded-xl border border-emerald-500/30 bg-emerald-500/10 p-3 text-xs text-emerald-300">
              Fee schedules updated and propagated into `nepseFeeEngine.ts`!
            </div>
          )}

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6 text-xs">
            {/* Regulatory Rates */}
            <div className="rounded-xl border border-bronze bg-obsidian p-4 space-y-3">
              <span className="font-bold text-champagne block border-b border-bronze/40 pb-1.5">
                Statutory Regulatory Fees
              </span>
              <div className="space-y-2">
                <div>
                  <label className="text-slate-400 block mb-1">SEBON Regulatory Fee Rate (%)</label>
                  <input
                    type="number"
                    step="0.001"
                    value={feeSchedule.sebonFeeRate * 100}
                    onChange={(e) =>
                      setFeeSchedule({
                        ...feeSchedule,
                        sebonFeeRate: Number(e.target.value) / 100,
                      })
                    }
                    className="w-full rounded-lg border border-bronze bg-charcoal p-2 text-white font-mono font-bold"
                  />
                  <span className="text-[10px] text-slate-500 block mt-0.5">Default: 0.015% (0.00015)</span>
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">CDSC DP Fee per Settlement (NPR)</label>
                  <input
                    type="number"
                    value={feeSchedule.dpFee}
                    onChange={(e) =>
                      setFeeSchedule({
                        ...feeSchedule,
                        dpFee: Number(e.target.value),
                      })
                    }
                    className="w-full rounded-lg border border-bronze bg-charcoal p-2 text-white font-mono font-bold"
                  />
                  <span className="text-[10px] text-slate-500 block mt-0.5">Flat Rs 25 per sell settlement</span>
                </div>
              </div>
            </div>

            {/* Capital Gains Tax */}
            <div className="rounded-xl border border-bronze bg-obsidian p-4 space-y-3">
              <span className="font-bold text-champagne block border-b border-bronze/40 pb-1.5">
                Capital Gains Tax (CGT) Slabs
              </span>
              <div className="space-y-2">
                <div>
                  <label className="text-slate-400 block mb-1">Individual Short-Term (&lt; 365 Days) %</label>
                  <input
                    type="number"
                    step="0.1"
                    value={feeSchedule.cgtShortTermRate * 100}
                    onChange={(e) =>
                      setFeeSchedule({
                        ...feeSchedule,
                        cgtShortTermRate: Number(e.target.value) / 100,
                      })
                    }
                    className="w-full rounded-lg border border-bronze bg-charcoal p-2 text-white font-mono font-bold"
                  />
                  <span className="text-[10px] text-slate-500 block mt-0.5">Statutory 7.5%</span>
                </div>
                <div>
                  <label className="text-slate-400 block mb-1">Individual Long-Term (&ge; 365 Days) %</label>
                  <input
                    type="number"
                    step="0.1"
                    value={feeSchedule.cgtLongTermRate * 100}
                    onChange={(e) =>
                      setFeeSchedule({
                        ...feeSchedule,
                        cgtLongTermRate: Number(e.target.value) / 100,
                      })
                    }
                    className="w-full rounded-lg border border-bronze bg-charcoal p-2 text-white font-mono font-bold"
                  />
                  <span className="text-[10px] text-slate-500 block mt-0.5">Statutory 5.0%</span>
                </div>
              </div>
            </div>
          </div>

          {/* Broker Slabs Display */}
          <div className="rounded-xl border border-bronze bg-obsidian p-4 space-y-2 text-xs">
            <span className="font-bold text-champagne block">Active 5-Tiered Broker Commission Slabs:</span>
            <div className="grid grid-cols-1 sm:grid-cols-5 gap-2 font-mono text-[11px]">
              <div className="border border-bronze/50 rounded-lg p-2.5 bg-charcoal">
                <span className="text-slate-400 block text-[9px]">Slab 1 (&le; 50k)</span>
                <span className="text-gold font-bold">0.40%</span>
                <span className="text-[9px] text-slate-500 block">Min Rs 10</span>
              </div>
              <div className="border border-bronze/50 rounded-lg p-2.5 bg-charcoal">
                <span className="text-slate-400 block text-[9px]">Slab 2 (50k - 5L)</span>
                <span className="text-gold font-bold">0.37%</span>
              </div>
              <div className="border border-bronze/50 rounded-lg p-2.5 bg-charcoal">
                <span className="text-slate-400 block text-[9px]">Slab 3 (5L - 20L)</span>
                <span className="text-gold font-bold">0.34%</span>
              </div>
              <div className="border border-bronze/50 rounded-lg p-2.5 bg-charcoal">
                <span className="text-slate-400 block text-[9px]">Slab 4 (20L - 1Cr)</span>
                <span className="text-gold font-bold">0.30%</span>
              </div>
              <div className="border border-bronze/50 rounded-lg p-2.5 bg-charcoal">
                <span className="text-slate-400 block text-[9px]">Slab 5 (&gt; 1Cr)</span>
                <span className="text-gold font-bold">0.27%</span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Tab 4: User RBAC */}
      {activeAdminTab === "users" && (
        <div className="rounded-2xl border border-bronze bg-charcoal overflow-hidden shadow-2xl">
          <div className="p-4 border-b border-bronze flex justify-between items-center">
            <h3 className="text-xs font-bold uppercase tracking-wider text-champagne">
              Active Institutional User Directory
            </h3>
            <span className="text-xs text-slate-400 font-mono">{users.length} Active Accounts</span>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs font-mono">
              <thead className="border-b border-bronze bg-obsidian font-sans text-[11px] uppercase tracking-wider text-slate-400">
                <tr>
                  <th className="py-3 px-4 font-semibold">User</th>
                  <th className="py-3 px-4 font-semibold">Role</th>
                  <th className="py-3 px-4 font-semibold">Status</th>
                  <th className="py-3 px-4 font-semibold">Subscription Tier</th>
                  <th className="py-3 px-4 font-semibold">Account Created</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-bronze/40">
                {users.map((u) => (
                  <tr key={u.id} className="hover:bg-obsidian/50 transition-colors">
                    <td className="py-3 px-4">
                      <div className="font-bold text-white font-sans">{u.name}</div>
                      <div className="text-[10px] text-slate-400">{u.email}</div>
                    </td>
                    <td className="py-3 px-4 font-sans">
                      <span className="rounded bg-gold/15 px-2 py-0.5 text-[10px] font-bold text-gold border border-gold/30">
                        {u.role}
                      </span>
                    </td>
                    <td className="py-3 px-4">
                      <span className="flex items-center space-x-1 text-emerald-400">
                        <CheckCircle2 className="h-3 w-3" />
                        <span>{u.status}</span>
                      </span>
                    </td>
                    <td className="py-3 px-4 font-sans text-champagne font-bold">{u.tier}</td>
                    <td className="py-3 px-4 text-slate-400">{u.createdAt}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Tab 5: Data Providers */}
      {activeAdminTab === "data-providers" && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {dataProviders.map((p) => (
              <div
                key={p.name}
                className="rounded-2xl border border-bronze bg-charcoal p-5 space-y-3 shadow-md"
              >
                <div className="flex items-center justify-between">
                  <span className="text-xs font-bold uppercase tracking-wider text-white">
                    {p.name}
                  </span>
                  <span
                    className={`rounded px-2 py-0.5 text-[10px] font-bold font-mono ${
                      p.status === "ONLINE"
                        ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                        : "bg-amber-500/20 text-amber-400 border border-amber-500/30"
                    }`}
                  >
                    {p.status}
                  </span>
                </div>
                <div className="space-y-1 font-mono text-xs text-slate-300">
                  <div className="flex justify-between">
                    <span className="text-slate-400">Endpoint:</span>
                    <span className="text-[10px] text-champagne truncate max-w-[140px]">{p.endpoint}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Latency:</span>
                    <span className="text-gold">{p.latencyMs} ms</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Records Today:</span>
                    <span className="text-emerald-400">{p.recordsSyncedToday.toLocaleString()}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-400">Last Sync:</span>
                    <span className="text-slate-400 text-[10px]">{p.lastSync}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Tab 6: Immutable Audit Ledger */}
      {activeAdminTab === "audit" && (
        <div className="rounded-2xl border border-bronze bg-charcoal overflow-hidden shadow-2xl space-y-4 p-5">
          <div className="flex items-center justify-between border-b border-bronze pb-3">
            <div>
              <h3 className="text-xs font-bold uppercase tracking-wider text-champagne flex items-center space-x-2">
                <Lock className="h-4 w-4 text-gold" />
                <span>Immutable Regulatory Audit Ledger</span>
              </h3>
              <p className="text-[11px] text-slate-400">
                Cryptographically tracked administrative operations, model updates, and regulatory fee modifications.
              </p>
            </div>
            <span className="text-xs font-mono text-gold">{auditLogs.length} Records</span>
          </div>

          <div className="space-y-2 font-mono text-xs">
            {auditLogs.map((log) => (
              <div
                key={log.id}
                className="flex flex-col sm:flex-row sm:items-center sm:justify-between rounded-xl border border-bronze bg-obsidian p-3 text-slate-300 gap-2"
              >
                <div className="space-y-0.5">
                  <div className="flex items-center space-x-2">
                    <span className="font-bold text-champagne">{log.adminEmail}</span>
                    <span className="rounded bg-gold/15 px-1.5 py-0.2 text-[9px] font-bold text-gold border border-gold/30">
                      {log.category}
                    </span>
                  </div>
                  <p className="text-[11px] text-slate-300 font-sans">{log.action}</p>
                  {log.newValue && (
                    <div className="text-[10px] text-slate-500">
                      <span className="text-slate-400 font-semibold">Value:</span> {log.newValue}
                    </div>
                  )}
                </div>
                <div className="text-right sm:shrink-0 text-[10px] text-slate-500">
                  <div>{log.timestamp.slice(0, 19).replace("T", " ")}</div>
                  <div>Trace: #{log.id}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}

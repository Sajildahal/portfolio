import type { Config } from "tailwindcss";

const config: Config = {
  darkMode: ["class"],
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  theme: {
    extend: {
      colors: {
        background: "var(--background)",
        foreground: "var(--foreground)",
        obsidian: {
          DEFAULT: "#080807",
          dark: "#050504",
          card: "#14120D",
          cardHover: "#1C1914",
          border: "#2A2415",
          borderLight: "#3D331D",
        },
        gold: {
          DEFAULT: "#D4AF37",
          champagne: "#F5E6A8",
          dim: "#A88B2A",
          muted: "#66541A",
          glow: "rgba(212, 175, 55, 0.15)",
        },
        nepse: {
          green: "#10B981",
          red: "#EF4444",
          gold: "#D4AF37",
          bronze: "#2A2415",
          obsidian: "#080807",
          card: "#14120D",
          cardLight: "#1C1914",
        },
      },
      boxShadow: {
        gold: "0 0 25px rgba(212, 175, 55, 0.15)",
        "gold-sm": "0 0 10px rgba(212, 175, 55, 0.12)",
        emerald: "0 0 20px rgba(16, 185, 129, 0.2)",
        rose: "0 0 20px rgba(239, 68, 68, 0.2)",
      },
    },
  },
  plugins: [],
};
export default config;

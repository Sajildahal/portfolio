"use client";

import React, { useState, useRef, useEffect } from "react";
import {
  Bot,
  Send,
  Sparkles,
  ShieldAlert,
  ArrowRight,
  HelpCircle,
  TrendingUp,
  AlertTriangle,
  CheckCircle2,
  Info,
  Clock,
  ChevronRight,
  Database,
  Terminal,
} from "lucide-react";
import { CopilotMessage, Holding, PortfolioSummary } from "@/types";
import { computeStockIntelligenceScore, analyzeSmartExit, diagnosePortfolioDoctor } from "@/lib/ai/institutionalEngine";
import { INITIAL_MARKET_PRICES } from "@/lib/market/nepseData";

interface InvestmentCopilotViewProps {
  holdings: Holding[];
  summary: PortfolioSummary;
  onSelectStock?: (symbol: string) => void;
}

const PRESET_QUERIES = [
  {
    label: "Why is NABIL recommended?",
    query: "Why is NABIL currently evaluated with an institutional recommendation?",
  },
  {
    label: "Downside risk in my holdings?",
    query: "Which holdings in my portfolio currently carry the highest downside risk?",
  },
  {
    label: "Stress test: NEPSE -10% drop",
    query: "What happens to my portfolio value if the NEPSE benchmark drops 10%?",
  },
  {
    label: "Exit criteria for top stock",
    query: "What are the exact stop-loss and trailing profit exit levels for my largest position?",
  },
  {
    label: "Averaging down vs cutting losses",
    query: "Is it advisable to average down on declining stocks right now in NEPSE?",
  },
];

export function InvestmentCopilotView({
  holdings,
  summary,
  onSelectStock,
}: InvestmentCopilotViewProps) {
  const [messages, setMessages] = useState<CopilotMessage[]>([
    {
      id: "intro-1",
      sender: "copilot",
      text: "Welcome to the NEPSE Institutional Investment Copilot. I analyze real-time market data, company financials, quantitative technical indicators, and portfolio risk distributions to provide evidence-based, transparent decision support.",
      timestamp: "Just now",
      evidenceCitations: [
        { label: "Engine", value: "NEPSE-QUANT-ENSEMBLE v3.4" },
        { label: "Status", value: "Audited Financials Calibrated" },
      ],
    },
  ]);
  const [inputQuery, setInputQuery] = useState("");
  const [isTyping, setIsTyping] = useState(false);
  const chatBottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    chatBottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, isTyping]);

  const handleSend = (queryText: string) => {
    const text = queryText.trim();
    if (!text) return;

    const userMsg: CopilotMessage = {
      id: "u-" + Date.now(),
      sender: "user",
      text,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputQuery("");
    setIsTyping(true);

    setTimeout(() => {
      const response = generateCopilotResponse(text, holdings, summary);
      setMessages((prev) => [...prev, response]);
      setIsTyping(false);
    }, 600);
  };

  const generateCopilotResponse = (
    query: string,
    currentHoldings: Holding[],
    currentSummary: PortfolioSummary
  ): CopilotMessage => {
    const q = query.toLowerCase();
    const timestamp = new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

    // 1. Stock specific query (e.g., NABIL, GBIME, SHIVM, etc.)
    const foundStock = INITIAL_MARKET_PRICES.find(
      (s) => q.includes(s.symbol.toLowerCase()) || q.includes(s.name.toLowerCase())
    );

    if (foundStock) {
      const hasPos = currentHoldings.some((h) => h.symbol === foundStock.symbol);
      const score = computeStockIntelligenceScore(foundStock.symbol, hasPos);

      return {
        id: "c-" + Date.now(),
        sender: "copilot",
        text: `Analysis for ${foundStock.name} (${foundStock.symbol}): Currently trading at NPR ${foundStock.ltp}. The quantitative model assigns an overall score of ${score.totalScore}/100. ${
          hasPos
            ? `Because you already own this position, the Stage B framework prescribes ${score.action}. ${score.primaryThesis}`
            : `Since you do not currently hold this stock, the framework evaluates prospective entry: ${score.action}. ${score.primaryThesis}`
        }`,
        timestamp,
        actionRecommendation: score.action,
        evidenceCitations: [
          { label: "Stock Intelligence Score", value: `${score.totalScore}/100` },
          { label: "Technical Factor", value: `${score.technicalStrength}/100` },
          { label: "Fundamental Factor", value: `${score.fundamentalQuality}/100` },
          { label: "Reward/Risk Ratio", value: `${score.rewardRiskRatio}:1` },
          { label: "Risk Score", value: `${score.riskScore}/100` },
          { label: "Liquidity", value: score.liquidityRating },
        ],
      };
    }

    // 2. Downside risk / weakness in portfolio
    if (q.includes("downside") || q.includes("risk") || q.includes("weakness")) {
      const diag = diagnosePortfolioDoctor(currentHoldings, currentSummary);
      const topRiskHolding = [...currentHoldings].sort(
        (a, b) => b.unrealizedPLPercent - a.unrealizedPLPercent
      )[currentHoldings.length - 1];

      return {
        id: "c-" + Date.now(),
        sender: "copilot",
        text: `Your overall Portfolio Risk Score is ${diag.portfolioRiskScore}/100 (${diag.riskBand}). ${
          topRiskHolding
            ? `Your largest unrealized drawdown holding is ${topRiskHolding.symbol} with an unrealized loss of ${topRiskHolding.unrealizedPLPercent.toFixed(1)}% (NPR ${Math.abs(topRiskHolding.unrealizedPL).toLocaleString()}).`
            : "No active holdings with deep drawdowns were detected."
        } ${diag.warnings[0]?.description || "Portfolio risk parameters are within acceptable thresholds."}`,
        timestamp,
        actionRecommendation: diag.portfolioRiskScore > 65 ? "REDUCE" : "HOLD",
        evidenceCitations: [
          { label: "Portfolio Risk Score", value: `${diag.portfolioRiskScore}/100` },
          { label: "Risk Band", value: diag.riskBand },
          { label: "Concentration Risk", value: `${diag.components.concentrationRisk}/100` },
          { label: "Active Warnings", value: `${diag.warnings.length} detected` },
        ],
      };
    }

    // 3. Stress testing query
    if (q.includes("10%") || q.includes("drop") || q.includes("crash") || q.includes("stress")) {
      const diag = diagnosePortfolioDoctor(currentHoldings, currentSummary);
      const scenario10 = diag.stressTestResults.find((s) => s.dropPercent === 10.0) || diag.stressTestResults[1];

      return {
        id: "c-" + Date.now(),
        sender: "copilot",
        text: `Under a systemic 10.0% NEPSE market correction, your total portfolio value would decline by approximately NPR ${scenario10?.estimatedLossNpr.toLocaleString()} to NPR ${scenario10?.portfolioValueAfter.toLocaleString()}. The highest monetary loss contributors would be your largest weighted holdings: ${scenario10?.topDetractors.map((d) => `${d.symbol} (-NPR ${d.lossNpr.toLocaleString()})`).join(", ")}.`,
        timestamp,
        actionRecommendation: "HOLD",
        evidenceCitations: [
          { label: "Estimated Drawdown", value: `-NPR ${scenario10?.estimatedLossNpr.toLocaleString()}` },
          { label: "Post-Shock Value", value: `NPR ${scenario10?.portfolioValueAfter.toLocaleString()}` },
          { label: "Cash Cushion", value: `NPR ${currentSummary.cashBalance.toLocaleString()}` },
        ],
      };
    }

    // 4. Exit criteria query
    if (q.includes("exit") || q.includes("stop") || q.includes("profit") || q.includes("criteria")) {
      const topHolding = currentHoldings[0];
      if (!topHolding) {
        return {
          id: "c-" + Date.now(),
          sender: "copilot",
          text: "You currently have no open positions in your portfolio. Once you add transactions, the Smart Exit Advisor will track continuous trailing protection and profit targets for each holding.",
          timestamp,
        };
      }

      const exitAnalysis = analyzeSmartExit(topHolding);

      return {
        id: "c-" + Date.now(),
        sender: "copilot",
        text: `Exit plan for your holding ${topHolding.symbol}: The Smart Exit Advisor recommends ${exitAnalysis.suggestedAction} with ${exitAnalysis.exitUrgency} urgency. Trailing capital protection should be raised to NPR ${exitAnalysis.trailingProtectionLevel}, and the hard stop-loss trigger is set at NPR ${exitAnalysis.recommendedStopLoss}. ${exitAnalysis.exitIntelligence[0] || ""}`,
        timestamp,
        actionRecommendation:
          exitAnalysis.suggestedAction === "URGENT EXIT / SELL"
            ? "SELL"
            : exitAnalysis.suggestedAction === "TAKE PARTIAL PROFIT" || exitAnalysis.suggestedAction === "REDUCE"
            ? "REDUCE"
            : "HOLD",
        evidenceCitations: [
          { label: "Holding", value: topHolding.symbol },
          { label: "Recommended Stop-Loss", value: `NPR ${exitAnalysis.recommendedStopLoss}` },
          { label: "Trailing Protection", value: `NPR ${exitAnalysis.trailingProtectionLevel}` },
          { label: "Thesis Status", value: exitAnalysis.thesisStatus },
        ],
      };
    }

    // 5. Averaging down query
    if (q.includes("average") || q.includes("averaging") || q.includes("cut")) {
      return {
        id: "c-" + Date.now(),
        sender: "copilot",
        text: "The institutional rule for NEPSE: Averaging down is ONLY permitted if the fundamental thesis remains superior (ROE > 14%, low debt, rising earnings) and the price is testing verified structural support. Averaging down on deteriorating, speculative, or high-P/E companies without confirmed support is classified as a high-risk error that magnifies portfolio drawdowns.",
        timestamp,
        actionRecommendation: "HOLD",
        evidenceCitations: [
          { label: "Rule", value: "Thesis First, Price Second" },
          { label: "Max Position Cap", value: "15% of Portfolio" },
          { label: "Prerequisite", value: "Confirmed Volume Rebound" },
        ],
      };
    }

    // Default institutional guidance
    return {
      id: "c-" + Date.now(),
      sender: "copilot",
      text: `Regarding "${query}": The NEPSE Intelligence AI system prioritizes capital preservation before speculative opportunity. You can query specific stock symbols (e.g., NABIL, GBIME, SHIVM), evaluate portfolio downside stress, inspect position exit rules, or check SEBON transaction fee breakdowns.`,
      timestamp,
      evidenceCitations: [
        { label: "Portfolio Value", value: `NPR ${currentSummary.currentMarketValue.toLocaleString()}` },
        { label: "Active Holdings", value: `${currentHoldings.length} stocks` },
      ],
    };
  };

  const getActionBadge = (action?: string) => {
    if (!action) return null;
    let color = "text-amber-400 bg-amber-500/10 border-amber-500/30";
    if (action === "BUY") color = "text-emerald-400 bg-emerald-500/20 border-emerald-500/40";
    if (action === "SELL") color = "text-rose-400 bg-rose-500/20 border-rose-500/40";
    if (action === "REDUCE") color = "text-orange-400 bg-orange-500/20 border-orange-500/40";
    if (action === "AVOID") color = "text-slate-400 bg-slate-800 border-slate-700";

    return (
      <span className={`rounded px-2 py-0.5 text-[11px] font-black border uppercase tracking-wider inline-block ${color}`}>
        {action}
      </span>
    );
  };

  return (
    <div className="space-y-6">
      {/* Header Banner */}
      <div className="rounded-2xl border border-bronze bg-charcoal p-6 shadow-gold">
        <div className="flex items-center space-x-2">
          <span className="flex items-center space-x-1.5 rounded-full bg-gold/15 px-3 py-1 text-xs font-bold text-gold border border-gold/30">
            <Bot className="h-3.5 w-3.5 text-gold" />
            <span>10 · INTERACTIVE DECISION SUPPORT COPILOT</span>
          </span>
          <span className="rounded-full bg-slate-800/80 px-2.5 py-0.5 text-[10px] font-mono text-champagne border border-bronze">
            VERIFIED EVIDENCE CITATIONS
          </span>
        </div>
        <h1 className="mt-2 text-2xl font-black text-white sm:text-3xl">
          AI Investment Copilot Terminal
        </h1>
        <p className="mt-1 text-xs text-slate-400 max-w-2xl">
          Ask questions about any NEPSE listed company, portfolio vulnerabilities, exit timings, or macro scenarios. Every answer provides evidence citations with exact data anchors.
        </p>
      </div>

      {/* Preset Query Chips */}
      <div className="flex items-center space-x-2 overflow-x-auto pb-1 text-xs">
        <span className="text-[10px] uppercase font-bold text-slate-500 shrink-0">Try asking:</span>
        {PRESET_QUERIES.map((preset, idx) => (
          <button
            key={idx}
            onClick={() => handleSend(preset.query)}
            className="flex items-center space-x-1.5 shrink-0 rounded-xl border border-bronze bg-charcoal/80 px-3 py-1.5 text-slate-300 hover:border-gold/40 hover:text-gold transition-colors"
          >
            <Sparkles className="h-3 w-3 text-gold" />
            <span>{preset.label}</span>
          </button>
        ))}
      </div>

      {/* Chat Terminal Box */}
      <div className="flex flex-col h-[560px] rounded-2xl border border-bronze bg-charcoal shadow-2xl overflow-hidden">
        {/* Terminal Header */}
        <div className="flex items-center justify-between border-b border-bronze bg-obsidian px-5 py-3 text-xs">
          <div className="flex items-center space-x-2">
            <div className="flex space-x-1.5">
              <span className="h-2.5 w-2.5 rounded-full bg-rose-500/80"></span>
              <span className="h-2.5 w-2.5 rounded-full bg-amber-500/80"></span>
              <span className="h-2.5 w-2.5 rounded-full bg-emerald-500/80"></span>
            </div>
            <span className="font-mono text-slate-400 font-bold ml-2">nepse-copilot-daemon://session-live</span>
          </div>
          <div className="flex items-center space-x-2 text-[11px] font-mono text-slate-500">
            <Database className="h-3.5 w-3.5 text-gold" />
            <span>NEPSE 282+ Equities Indexed</span>
          </div>
        </div>

        {/* Message Log */}
        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          {messages.map((msg) => (
            <div
              key={msg.id}
              className={`flex flex-col ${msg.sender === "user" ? "items-end" : "items-start"}`}
            >
              <div className="flex items-center space-x-2 mb-1 px-1">
                <span className="text-[10px] font-bold text-slate-500 uppercase tracking-wider">
                  {msg.sender === "user" ? "You (Investor)" : "NEPSE Copilot AI"}
                </span>
                <span className="text-[10px] text-slate-600 font-mono">{msg.timestamp}</span>
              </div>

              <div
                className={`max-w-2xl rounded-2xl p-4 text-xs leading-relaxed ${
                  msg.sender === "user"
                    ? "bg-gold/15 border border-gold/30 text-white rounded-tr-none"
                    : "bg-obsidian border border-bronze text-slate-200 rounded-tl-none shadow-lg"
                }`}
              >
                {/* Action Recommendation Banner if present */}
                {msg.actionRecommendation && (
                  <div className="mb-2.5 flex items-center space-x-2">
                    <span className="text-[10px] text-slate-400 uppercase font-mono">Prescribed Action:</span>
                    {getActionBadge(msg.actionRecommendation)}
                  </div>
                )}

                <p className="whitespace-pre-wrap">{msg.text}</p>

                {/* Evidence Citations */}
                {msg.evidenceCitations && msg.evidenceCitations.length > 0 && (
                  <div className="mt-3 pt-3 border-t border-bronze/50 space-y-1.5">
                    <span className="text-[9px] font-bold uppercase tracking-wider text-slate-500 block">
                      Evidence &amp; Analytical Citations:
                    </span>
                    <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                      {msg.evidenceCitations.map((c, i) => (
                        <div
                          key={i}
                          className="rounded-lg border border-bronze/60 bg-charcoal/60 px-2 py-1 text-[11px]"
                        >
                          <span className="text-slate-400 block text-[9px]">{c.label}</span>
                          <span className="font-mono font-bold text-champagne">{c.value}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                )}
              </div>
            </div>
          ))}

          {isTyping && (
            <div className="flex items-center space-x-2 text-slate-500 text-xs italic">
              <Bot className="h-4 w-4 animate-spin text-gold" />
              <span>Analyzing market signals, balance sheets, and risk factors...</span>
            </div>
          )}
          <div ref={chatBottomRef} />
        </div>

        {/* Input Bar */}
        <div className="border-t border-bronze bg-obsidian p-3 sm:p-4">
          <form
            onSubmit={(e) => {
              e.preventDefault();
              handleSend(inputQuery);
            }}
            className="flex items-center space-x-3"
          >
            <input
              type="text"
              value={inputQuery}
              onChange={(e) => setInputQuery(e.target.value)}
              placeholder="Ask Copilot about any NEPSE stock, valuation, risk, or exit criteria..."
              className="flex-1 rounded-xl border border-bronze bg-charcoal px-4 py-2.5 text-xs text-white placeholder-slate-500 focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold"
            />
            <button
              type="submit"
              disabled={!inputQuery.trim() || isTyping}
              className="flex items-center space-x-2 rounded-xl gold-gradient-btn px-4 py-2.5 text-xs font-bold transition-all disabled:opacity-50"
            >
              <span>Ask</span>
              <Send className="h-3.5 w-3.5" />
            </button>
          </form>
        </div>
      </div>
    </div>
  );
}

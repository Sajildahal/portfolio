"use client";

import React, { useState } from "react";
import {
  Bell,
  Search,
  Activity,
  Shield,
  TrendingUp,
  Clock,
  Layers,
  ChevronDown,
  Sun,
  Moon,
  Sparkles,
} from "lucide-react";
import { INITIAL_INDICES } from "@/lib/market/nepseData";

interface NavbarProps {
  onSearchSelect?: (symbol: string) => void;
  onOpenNotifications?: () => void;
  activePortfolioName: string;
  theme?: "dark" | "light";
  onToggleTheme?: () => void;
}

export function Navbar({
  onSearchSelect,
  onOpenNotifications,
  activePortfolioName,
  theme = "dark",
  onToggleTheme,
}: NavbarProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const nepseIndex = INITIAL_INDICES[0];
  const sensitiveIndex = INITIAL_INDICES[1];

  return (
    <header className="sticky top-0 z-40 w-full border-b border-bronze bg-charcoal/95 backdrop-blur-md">
      {/* Top Real-time Ticker Ribbon */}
      <div className="flex h-7 items-center justify-between overflow-x-auto border-b border-bronze/60 px-4 text-xs font-mono text-slate-300 bg-obsidian">
        <div className="flex items-center space-x-6 min-w-max">
          <div className="flex items-center space-x-2">
            <span className="inline-block h-2 w-2 rounded-full bg-emerald-500 animate-ping"></span>
            <span className="text-slate-400 font-sans">MARKET STATUS:</span>
            <span className="font-semibold text-emerald-400">REGULAR SESSION (VERIFIED LIVE)</span>
          </div>

          <div className="flex items-center space-x-2">
            <span className="text-slate-400">NEPSE:</span>
            <span className="font-bold text-white">{nepseIndex.current.toLocaleString()}</span>
            <span className="text-emerald-400 font-semibold">
              +{nepseIndex.change} (+{nepseIndex.changePercent}%)
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <span className="text-slate-400">SENSITIVE:</span>
            <span className="font-bold text-white">{sensitiveIndex.current.toLocaleString()}</span>
            <span className="text-emerald-400 font-semibold">
              +{sensitiveIndex.change} (+{sensitiveIndex.changePercent}%)
            </span>
          </div>

          <div className="flex items-center space-x-2">
            <span className="text-slate-400">TOTAL TURNOVER:</span>
            <span className="font-bold text-gold">NPR 6.84 Arba</span>
          </div>
        </div>

        <div className="flex items-center space-x-3 text-slate-400 font-sans">
          <Clock className="h-3 w-3 text-gold" />
          <span>AS OF: 02 NOV 2026 15:00 NPT · SEBON SYNCED</span>
        </div>
      </div>

      {/* Main App Navigation Bar */}
      <div className="flex h-16 items-center justify-between px-6">
        <div className="flex items-center space-x-4">
          <div className="flex items-center space-x-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl gold-gradient-btn shadow-gold">
              <TrendingUp className="h-6 w-6 text-black" />
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <span className="text-lg font-black tracking-tight text-white">NEPSE</span>
                <span className="rounded-md bg-gold/20 px-1.5 py-0.5 text-[11px] font-bold text-gold border border-gold/30">
                  INTELLIGENCE AI
                </span>
                <span className="rounded bg-rose-500/20 px-1.5 py-0.5 text-[9px] font-bold text-rose-300 border border-rose-500/30">
                  INSTITUTIONAL
                </span>
              </div>
              <p className="text-[10px] text-slate-400 uppercase tracking-wider font-medium">
                Capital Protection &amp; Quantitative Intelligence
              </p>
            </div>
          </div>
        </div>

        {/* Global Search Bar */}
        <div className="relative w-80 max-w-md hidden md:block">
          <div className="absolute inset-y-0 left-0 flex items-center pl-3 pointer-events-none text-slate-400">
            <Search className="h-4 w-4" />
          </div>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === "Enter" && searchQuery.trim() && onSearchSelect) {
                onSearchSelect(searchQuery.trim().toUpperCase());
              }
            }}
            placeholder="Search stock by symbol (e.g. NABIL, GBIME)..."
            className="w-full rounded-xl border border-bronze bg-obsidian py-2 pl-9 pr-4 text-xs text-white placeholder-slate-500 transition-all focus:border-gold focus:outline-none focus:ring-1 focus:ring-gold"
          />
        </div>

        {/* Right Action Icons & Profile */}
        <div className="flex items-center space-x-3">
          {/* Active Portfolio Badge */}
          <div className="hidden sm:flex items-center space-x-2 rounded-xl border border-bronze bg-obsidian px-3 py-1.5">
            <Layers className="h-3.5 w-3.5 text-gold" />
            <div className="text-left">
              <span className="block text-[9px] uppercase font-bold text-slate-400">Active Book</span>
              <span className="block text-xs font-bold text-champagne">{activePortfolioName}</span>
            </div>
            <ChevronDown className="h-3 w-3 text-slate-500" />
          </div>

          {/* Theme Toggle Button */}
          {onToggleTheme && (
            <button
              onClick={onToggleTheme}
              className="flex h-9 w-9 items-center justify-center rounded-xl border border-bronze bg-obsidian text-slate-400 hover:text-gold hover:border-gold/40 transition-colors"
              title="Toggle Dark / Light Theme"
            >
              {theme === "dark" ? <Sun className="h-4 w-4" /> : <Moon className="h-4 w-4" />}
            </button>
          )}

          {/* User Profile Avatar */}
          <div className="flex items-center space-x-2 pl-2">
            <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-tr from-gold to-champagne font-bold text-black text-xs shadow-gold">
              NI
            </div>
            <div className="hidden lg:block text-left">
              <span className="block text-xs font-bold text-white">Chief Risk Officer</span>
              <span className="block text-[10px] text-gold font-mono">SEBON Tier-1</span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
